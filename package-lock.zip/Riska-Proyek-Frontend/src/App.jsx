import React from 'react';
import ProdukList from './components/ProdukList';

function App() {
  return (
    <div>
      <h1>Selamat Datang di Aplikasi E-Commerce Sederhana</h1>
      <ProdukList />
    </div>
  );
}

export default App;